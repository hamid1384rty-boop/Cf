package com.example.cfpanel

import android.util.Base64
import org.json.JSONObject

object Ports {
    val TLS = listOf(443, 2053, 2083, 2087, 2096)
    val PLAIN = listOf(80, 2052, 2082, 2086, 2095)
    val ALL = TLS + PLAIN
    fun label(p: Int) = "$p " + if (p in TLS) "(TLS)" else "(no TLS)"
}

object ConfigRewriter {
    private val LINK = Regex("""^([a-zA-Z]+://[^@]+@)(\[[^\]]+\]|[^:/?#]+):(\d+)(\?[^#]*)?(#.*)?$""")

    // Subscription is usually base64 of newline-separated links
    fun parseSub(raw: String): List<String> {
        val text = try {
            String(Base64.decode(raw.trim(), Base64.DEFAULT))
        } catch (e: Exception) {
            raw
        }
        return text.lines().map { it.trim() }.filter { it.contains("://") }
    }

    fun endpoint(link: String): Pair<String, Int>? {
        if (link.startsWith("vmess://")) {
            return try {
                val j = vmessJson(link)
                j.getString("add") to j.getString("port").toInt()
            } catch (e: Exception) { null }
        }
        val m = LINK.find(link) ?: return null
        return m.groupValues[2] to m.groupValues[3].toInt()
    }

    // Replace address and port with ip + port, and set TLS according to the port
    fun rewrite(link: String, ip: String, port: Int): String? {
        val tls = port in Ports.TLS
        if (link.startsWith("vmess://")) {
            return try {
                val j = vmessJson(link)
                j.put("add", ip)
                j.put("port", port.toString())
                j.put("tls", if (tls) "tls" else "")
                "vmess://" + Base64.encodeToString(j.toString().toByteArray(), Base64.NO_WRAP)
            } catch (e: Exception) { null }
        }
        val m = LINK.find(link) ?: return null
        val query = m.groupValues[4].removePrefix("?")
            .split("&")
            .filter { it.isNotEmpty() && !it.startsWith("security=") }
            .toMutableList()
        query.add("security=" + if (tls) "tls" else "none")
        val frag = m.groupValues[5]
        return m.groupValues[1] + ip + ":" + port + "?" + query.joinToString("&") + frag
    }

    private fun vmessJson(link: String): JSONObject =
        JSONObject(String(Base64.decode(link.removePrefix("vmess://"), Base64.DEFAULT)))
}
