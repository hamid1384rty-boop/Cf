package com.example.cfpanel

import android.content.Context

object Prefs {
    private const val FILE = "cfpanel"
    private const val KEY_WHITE = "white_ips"

    fun white(ctx: Context): MutableList<String> {
        val raw = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString(KEY_WHITE, "") ?: ""
        return raw.lines().map { it.trim() }.filter { it.isNotEmpty() }.toMutableList()
    }

    fun saveWhite(ctx: Context, ips: List<String>) {
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .edit().putString(KEY_WHITE, ips.distinct().joinToString("\n")).apply()
    }
}
