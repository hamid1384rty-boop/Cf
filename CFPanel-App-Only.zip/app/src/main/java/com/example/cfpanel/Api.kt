package com.example.cfpanel

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Api {
    // Replace with your deployed worker URL
    const val BASE = "https://dark-math-9990.hamid1384uio.workers.dev"

    fun login(username: String, password: String): JSONObject {
        val conn = URL("$BASE/api/app/login").openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.doOutput = true
        conn.connectTimeout = 15000
        conn.readTimeout = 30000
        conn.setRequestProperty("content-type", "application/json")
        val payload = JSONObject().put("username", username).put("password", password).toString()
        conn.outputStream.use { it.write(payload.toByteArray()) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val body = stream.bufferedReader().use { it.readText() }
        conn.disconnect()
        return JSONObject(body)
    }

    // Downloads one subscription link (done by the app, not the worker)
    fun fetchSub(url: String): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 15000
        conn.readTimeout = 30000
        conn.setRequestProperty("user-agent", "v2rayNG/1.8.0")
        val text = conn.inputStream.bufferedReader().use { it.readText() }
        conn.disconnect()
        return text
    }
}
