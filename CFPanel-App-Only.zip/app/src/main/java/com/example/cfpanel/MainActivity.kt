package com.example.cfpanel

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val bg = Executors.newSingleThreadExecutor()
    private var scanner: IpScanner? = null

    private var configs = listOf<String>()   // from subscription
    private var shown = listOf<String>()     // after apply / sort
    private val latency = mutableMapOf<String, Long>()

    private lateinit var loginBox: LinearLayout
    private lateinit var mainBox: LinearLayout
    private lateinit var userIn: EditText
    private lateinit var passIn: EditText
    private lateinit var infoView: TextView
    private lateinit var statusView: TextView
    private lateinit var whiteBox: LinearLayout
    private lateinit var manualIn: EditText
    private lateinit var configView: TextView
    private lateinit var portSpinner: Spinner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this)
        val col = vbox()
        col.setPadding(32, 32, 32, 32)
        scroll.addView(col)
        setContentView(scroll)

        statusView = text("")

        loginBox = vbox()
        userIn = EditText(this).apply { hint = "نام کاربری" }
        passIn = EditText(this).apply {
            hint = "رمز"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        loginBox.addView(text("ورود"))
        loginBox.addView(userIn)
        loginBox.addView(passIn)
        loginBox.addView(button("ورود") { login() })

        mainBox = vbox()
        mainBox.visibility = View.GONE
        infoView = text("")
        mainBox.addView(infoView)

        mainBox.addView(text("--- اسکنر آی‌پی کلودفلر ---"))
        mainBox.addView(button("اسکن آی‌پی‌های جدید") { startScan() })
        mainBox.addView(button("توقف") { scanner?.stop(); status("توقف شد") })

        mainBox.addView(text("--- آی‌پی‌های سفید ---"))
        whiteBox = vbox()
        mainBox.addView(whiteBox)
        manualIn = EditText(this).apply { hint = "آی‌پی جدید" }
        mainBox.addView(manualIn)
        mainBox.addView(button("اضافه کردن") { addManualIp() })
        mainBox.addView(button("اسکن مجدد لیست") { rescanWhite() })

        mainBox.addView(text("--- کانفیگ‌ها ---"))
        portSpinner = Spinner(this)
        portSpinner.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, Ports.ALL.map { Ports.label(it) }
        )
        mainBox.addView(portSpinner)
        mainBox.addView(button("تست کانفیگ‌ها") { testConfigs() })
        mainBox.addView(button("مرتب‌سازی بر اساس سرعت (سریع‌ترین بالا)") { sortByLatency() })
        mainBox.addView(button("تنظیم کانفیگ‌ها با آی‌پی سفید") { applyWhite() })
        mainBox.addView(button("کپی همه کانفیگ‌ها") { copyConfigs() })
        configView = text("")
        mainBox.addView(configView)

        col.addView(statusView)
        col.addView(loginBox)
        col.addView(mainBox)
        renderWhite()
    }

    private fun vbox() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    }

    private fun text(s: String) = TextView(this).apply { text = s; setPadding(0, 12, 0, 4) }

    private fun button(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        setOnClickListener { onClick() }
    }

    private fun status(s: String) = runOnUiThread { statusView.text = s }

    private fun login() {
        val u = userIn.text.toString().trim()
        val p = passIn.text.toString()
        status("در حال ورود...")
        bg.execute {
            try {
                val j = Api.login(u, p)
                val subList = if (j.optBoolean("ok")) {
                    val arr = j.getJSONArray("subs")
                    (0 until arr.length()).flatMap { i ->
                        try { ConfigRewriter.parseSub(Api.fetchSub(arr.getString(i))) } catch (e: Exception) { emptyList() }
                    }
                } else emptyList()
                runOnUiThread {
                    if (j.optBoolean("ok")) {
                        val user = j.getJSONObject("user")
                        configs = subList
                        shown = configs
                        val quota = user.getLong("quotaBytes")
                        val used = user.getLong("usedBytes")
                        val gb = 1024.0 * 1024 * 1024
                        infoView.text = "کاربر: ${user.getString("name")}\n" +
                            "حجم: ${"%.2f".format(used / gb)} / " +
                            (if (quota > 0) "%.2f GB".format(quota / gb) else "نامحدود") + "\n" +
                            "انقضا: ${user.optString("expiresAt").ifEmpty { "-" }}\n" +
                            "تعداد کانفیگ: ${configs.size}"
                        loginBox.visibility = View.GONE
                        mainBox.visibility = View.VISIBLE
                        render()
                        status("")
                    } else {
                        status(j.optString("error", "خطا"))
                    }
                }
            } catch (e: Exception) {
                status("خطا در اتصال به سرور")
            }
        }
    }

    private fun startScan() {
        if (scanner != null) return
        status("در حال اسکن...")
        val s = IpScanner { done, total -> status("اسکن $done از $total") }
        scanner = s
        bg.execute {
            val found = s.scan(Cloudflare.randomIps(400))
            Prefs.saveWhite(this, Prefs.white(this) + found.map { it.first })
            scanner = null
            runOnUiThread { renderWhite(); status("اسکن تموم شد: ${found.size} آی‌پی سالم پیدا شد") }
        }
    }

    private fun rescanWhite() {
        if (scanner != null) return
        val list = Prefs.white(this)
        if (list.isEmpty()) { status("لیست سفید خالیه"); return }
        status("اسکن مجدد لیست...")
        val s = IpScanner { done, total -> status("اسکن $done از $total") }
        scanner = s
        bg.execute {
            val alive = s.scan(list).map { it.first }
            Prefs.saveWhite(this, alive)
            scanner = null
            runOnUiThread { renderWhite(); status("${alive.size} از ${list.size} آی‌پی زنده موند") }
        }
    }

    private fun addManualIp() {
        val ip = manualIn.text.toString().trim()
        if (ip.isEmpty()) return
        Prefs.saveWhite(this, Prefs.white(this) + ip)
        manualIn.setText("")
        renderWhite()
    }

    private fun removeIp(ip: String) {
        Prefs.saveWhite(this, Prefs.white(this).filter { it != ip })
        renderWhite()
    }

    private fun renderWhite() {
        whiteBox.removeAllViews()
        for (ip in Prefs.white(this)) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            row.addView(TextView(this).apply { text = ip; layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f) })
            row.addView(Button(this).apply { text = "حذف"; setOnClickListener { removeIp(ip) } })
            whiteBox.addView(row)
        }
    }

    private fun applyWhite() {
        val white = Prefs.white(this)
        if (white.isEmpty()) { status("اول آی‌پی سفید اضافه کن"); return }
        val port = Ports.ALL[portSpinner.selectedItemPosition]
        val base = if (shown.isEmpty()) configs else shown
        shown = base.mapNotNull { ConfigRewriter.rewrite(it, white.random(), port) }
        render()
        status("${shown.size} کانفیگ با پورت $port تنظیم شد")
    }

    private fun testConfigs() {
        val list = if (shown.isEmpty()) configs else shown
        if (list.isEmpty()) { status("کانفیگی نیست"); return }
        status("در حال تست کانفیگ‌ها...")
        bg.execute {
            list.forEach { link ->
                val ep = ConfigRewriter.endpoint(link)
                val ms = ep?.let { Latency.measure(it.first, it.second, 3000) }
                synchronized(latency) { if (ms != null) latency[link] = ms else latency.remove(link) }
            }
            runOnUiThread {
                shown = sortedByLatency(list)
                render()
                status("تست تموم شد: ${list.count { latency.containsKey(it) }} کانفیگ جواب داد")
            }
        }
    }

    private fun sortByLatency() {
        shown = sortedByLatency(if (shown.isEmpty()) configs else shown)
        render()
    }

    private fun sortedByLatency(list: List<String>) =
        list.sortedBy { latency[it] ?: Long.MAX_VALUE }

    private fun render() {
        configView.text = shown.take(50).joinToString("\n\n") { link ->
            val ms = latency[link]?.let { "$it ms" } ?: "-"
            "[$ms] ${link.take(80)}"
        } + if (shown.size > 50) "\n\n... و ${shown.size - 50} کانفیگ دیگه (با دکمه کپی همه بگیرش)" else ""
    }

    private fun copyConfigs() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("configs", (if (shown.isEmpty()) configs else shown).joinToString("\n")))
        status("کپی شد")
    }
}
