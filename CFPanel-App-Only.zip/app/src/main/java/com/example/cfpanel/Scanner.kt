package com.example.cfpanel

import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import kotlin.random.Random

object Cloudflare {
    private val RANGES = listOf(
        "104.16.0.0/13", "104.24.0.0/14", "172.64.0.0/13", "162.159.0.0/16",
        "188.114.96.0/20", "141.101.64.0/18", "108.162.192.0/18",
        "190.93.240.0/20", "197.234.240.0/22", "198.41.128.0/17"
    )

    private fun ipToLong(ip: String): Long =
        ip.split(".").fold(0L) { acc, p -> (acc shl 8) or p.toLong() }

    private fun longToIp(v: Long): String =
        listOf(24, 16, 8, 0).joinToString(".") { ((v shr it) and 255).toString() }

    fun randomIps(count: Int): List<String> {
        val out = LinkedHashSet<String>()
        while (out.size < count) {
            val cidr = RANGES[Random.nextInt(RANGES.size)]
            val parts = cidr.split("/")
            val base = ipToLong(parts[0])
            val bits = parts[1].toInt()
            val size = 1L shl (32 - bits)
            val mask = (0xFFFFFFFFL shl (32 - bits)) and 0xFFFFFFFFL
            out.add(longToIp((base and mask) + Random.nextLong(size)))
        }
        return out.toList()
    }
}

object Latency {
    fun measure(host: String, port: Int, timeoutMs: Int): Long? = try {
        val start = System.nanoTime()
        Socket().use { it.connect(InetSocketAddress(host, port), timeoutMs) }
        (System.nanoTime() - start) / 1_000_000
    } catch (e: Exception) {
        null
    }
}

class IpScanner(private val onProgress: (done: Int, total: Int) -> Unit) {
    private val stopFlag = AtomicBoolean(false)

    fun stop() = stopFlag.set(true)

    // Returns working ips sorted by latency (fastest first)
    fun scan(ips: List<String>, port: Int = 443, timeoutMs: Int = 1500): List<Pair<String, Long>> {
        stopFlag.set(false)
        val pool = Executors.newFixedThreadPool(64)
        val done = AtomicInteger(0)
        val futures = ips.map { ip ->
            pool.submit<Pair<String, Long>?> {
                if (stopFlag.get()) null
                else {
                    val ms = Latency.measure(ip, port, timeoutMs)
                    onProgress(done.incrementAndGet(), ips.size)
                    ms?.let { ip to it }
                }
            }
        }
        val results = futures.mapNotNull { runCatching { it.get() }.getOrNull() }
        pool.shutdownNow()
        return results.sortedBy { it.second }
    }
}
